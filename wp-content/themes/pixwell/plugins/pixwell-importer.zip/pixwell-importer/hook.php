<?php
defined( 'ABSPATH' ) || exit;

/** config import for Pixwell */
add_filter( 'rb_importer_demo_plugins', 'pixwell_importer_plugins' );
add_filter( 'rb_importer_theme_option_name', 'pixwell_theme_option_name' );
add_filter( 'rb_importer_demo_name', 'pixwell_importer_demo_name' );
add_action( 'rb_importer_before_content', 'pixwell_importer_duplicate_menus' );
add_action( 'rb_importer_before_widgets', 'pixwell_importer_init_widgets' );
add_action( 'rb_importer_content_settings', 'pixwell_importer_setup_content', 10, 1 );
add_action( 'rb_importer_content_settings', 'pixwell_importer_setup_category', 20, 2 );
add_action( 'rb_importer_after_theme_options', 'pixwell_importer_remove_cache' );
add_action( 'rb_importer_header', 'pixwell_importer_header' );

/** setup plugins */
if ( ! function_exists( 'pixwell_importer_plugins' ) ) {
	function pixwell_importer_plugins( $directory ) {

		switch ( $directory ) {
			case '11' :
			case '13' :
			case '14' :
			case '15' :
			case '16' :
			case '26':
			case '17' :
				return [
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Cooked – Recipe Management', 'pixwell-importer' ),
						'slug' => 'cooked',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Post Views Counter', 'pixwell-importer' ),
						'slug' => 'post-views-counter',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '12' :
				return [
					[
						'name' => esc_html__( 'WooCommerce', 'pixwell-importer' ),
						'slug' => 'woocommerce',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'YITH WooCommerce Wishlist', 'pixwell-importer' ),
						'slug' => 'yith-woocommerce-wishlist',
						'file' => 'init',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Post Views Counter', 'pixwell-importer' ),
						'slug' => 'post-views-counter',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '18' :
				return [
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Post Views Counter', 'pixwell-importer' ),
						'slug' => 'post-views-counter',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '19' :
				return [
					[
						'name' => esc_html__( 'Post Views Counter', 'pixwell-importer' ),
						'slug' => 'post-views-counter',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '29':
			case '20' :
				return [
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '21' :
			case '24' :
				return [
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '22' :
			case '23' :
				return [
					[
						'name'   => esc_html__( 'Pixwell Deal', 'pixwell-importer' ),
						'slug'   => 'pixwell-deal',
						'class'  => 'important',
						'source' => get_theme_file_path( 'plugins/pixwell-deal.zip' ),
						'info'   => esc_html__( 'Required', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '25' :
				return [
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '27' :
				return [
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '28' :
				return [
					[
						'name' => esc_html__( 'WooCommerce', 'pixwell-importer' ),
						'slug' => 'woocommerce',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '30' :
				return [
					[
						'name' => esc_html__( 'WooCommerce', 'pixwell-importer' ),
						'slug' => 'woocommerce',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '31' :
				return [
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '32' :
			case '33' :
				return [
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '34' :
				return [
					[
						'name'  => esc_html__( 'Elementor Website Builder', 'pixwell-importer' ),
						'slug'  => 'elementor',
						'class' => 'important',
						'info'  => esc_html__( 'Required', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Breadcrumb NavXT', 'pixwell-importer' ),
						'slug' => 'breadcrumb-navxt',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'PublishPress Authors', 'pixwell-importer' ),
						'slug' => 'publishpress-authors',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '35' :
				return [
					[
						'name'  => esc_html__( 'Elementor Website Builder', 'pixwell-importer' ),
						'slug'  => 'elementor',
						'class' => 'important',
						'info'  => esc_html__( 'Required', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '36' :
			case '37' :
			case '38' :
			case '39' :
			case '45':
			case '44':
			case '43':
			case '42':
			case '41' :
				return [
					[
						'name'  => esc_html__( 'Elementor Website Builder', 'pixwell-importer' ),
						'slug'  => 'elementor',
						'class' => 'important',
						'info'  => esc_html__( 'Required', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '40' :
				return [
					[
						'name'  => esc_html__( 'Elementor Website Builder', 'pixwell-importer' ),
						'slug'  => 'elementor',
						'class' => 'important',
						'info'  => esc_html__( 'Required', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Cryptocurrency Widgets Pack', 'pixwell-importer' ),
						'slug' => 'cryptocurrency-widgets-pack',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '46' :
				return [
					[
						'name'  => esc_html__( 'Elementor Website Builder', 'pixwell-importer' ),
						'slug'  => 'elementor',
						'class' => 'important',
						'info'  => esc_html__( 'Required', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'MC4WP: Mailchimp for WordPress', 'pixwell-importer' ),
						'slug' => 'mailchimp-for-wp',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Simple Membership', 'pixwell-importer' ),
						'slug' => 'simple-membership',
						'file' => 'simple-wp-membership',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			case '47' :
				return [
					[
						'name'  => esc_html__( 'WP Recipe Maker', 'pixwell-importer' ),
						'slug'  => 'wp-recipe-maker',
						'class' => 'important',
						'info'  => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
					[
						'name' => esc_html__( 'Contact Form 7', 'pixwell-importer' ),
						'slug' => 'contact-form-7',
						'file' => 'wp-contact-form-7',
						'info' => esc_html__( 'Recommended', 'pixwell-importer' ),
					],
				];
			default :
				return false;
		}
	}
}

/** theme options */
if ( ! function_exists( 'pixwell_theme_option_name' ) ) {
	function pixwell_theme_option_name() {

		return 'pixwell_theme_options';
	}
}

/** setup content */
if ( ! function_exists( 'pixwell_importer_demo_name' ) ) {
	function pixwell_importer_demo_name( $directory ) {

		switch ( $directory ) {
			case '11' :
				return esc_html__( 'Recipe Concept', 'pixwell-importer' );
			case '12' :
				return esc_html__( 'Fashion Concept', 'pixwell-importer' );
			case '13' :
				return esc_html__( 'Technology Concept', 'pixwell-importer' );
			case '14' :
				return esc_html__( 'Travel Concept', 'pixwell-importer' );
			case '15' :
				return esc_html__( 'LifeStyle Concept', 'pixwell-importer' );
			case '16' :
				return esc_html__( 'Photography Concept', 'pixwell-importer' );
			case '17' :
				return esc_html__( 'Baby Concept', 'pixwell-importer' );
			case '18' :
				return esc_html__( 'Blogger Concept', 'pixwell-importer' );
			case '19' :
				return esc_html__( 'Work Portfolio', 'pixwell-importer' );
			case '20' :
				return esc_html__( 'Food Concept', 'pixwell-importer' );
			case '21' :
				return esc_html__( 'Gadget Concept', 'pixwell-importer' );
			case '22' :
				return esc_html__( 'Review & Deal Concept', 'pixwell-importer' );
			case '23' :
				return esc_html__( 'Fashion Deal Concept', 'pixwell-importer' );
			case '24' :
				return esc_html__( 'Freebie Concept', 'pixwell-importer' );
			case '25' :
				return esc_html__( 'Sport Concept', 'pixwell-importer' );
			case '26' :
				return esc_html__( 'RTL Concept', 'pixwell-importer' );
			case '27' :
				return esc_html__( 'Decor Concept', 'pixwell-importer' );
			case '28' :
				return esc_html__( 'Beauty Concept', 'pixwell-importer' );
			case '29' :
				return esc_html__( 'Medical Concept', 'pixwell-importer' );
			case '30' :
				return esc_html__( 'Yoga Concept', 'pixwell-importer' );
			case '31' :
				return esc_html__( 'Marketing Concept', 'pixwell-importer' );
			case '32' :
				return esc_html__( 'Application Concept', 'pixwell-importer' );
			case '33' :
				return esc_html__( 'Game Concept', 'pixwell-importer' );
			case '34' :
				return esc_html__( 'Tutorial Concept', 'pixwell-importer' );
			case '35' :
				return esc_html__( 'HowTos Concept', 'pixwell-importer' );
			case '36' :
				return esc_html__( 'Podcast Concept', 'pixwell-importer' );
			case '37' :
				return esc_html__( 'Software Concept', 'pixwell-importer' );
			case '38' :
				return esc_html__( 'Outfit Concept', 'pixwell-importer' );
			case '39' :
				return esc_html__( 'Military Concept', 'pixwell-importer' );
			case '40' :
				return esc_html__( 'Cryptocurrency Concept', 'pixwell-importer' );
			case '41' :
				return esc_html__( 'Wedding Concept', 'pixwell-importer' );
			case '42' :
				return esc_html__( 'Architecture Concept', 'pixwell-importer' );
			case '43' :
				return esc_html__( 'Baby Care Concept', 'pixwell-importer' );
			case '44' :
				return esc_html__( 'Breaking News Concept', 'pixwell-importer' );
			case '45' :
				return esc_html__( 'Wellness Concept', 'pixwell-importer' );
			case '46' :
				return esc_html__( 'Today Concept', 'pixwell-importer' );
			case '47' :
				return esc_html__( 'Recipe Maker', 'pixwell-importer' );
			default:
				return $directory;
		}
	}
}

/** setup content */
if ( ! function_exists( 'pixwell_importer_setup_content' ) ) {
	function pixwell_importer_setup_content( $directory ) {

		$homepage = '';
		if ( defined( 'ELEMENTOR_VERSION' ) ) {
			switch ( $directory ) {
				case '11' :
					$homepage = 'Elementor Recipe';
					break;
				case '12' :
					$homepage = 'Elementor Fashion';
					break;
				case '13' :
					$homepage = 'Elementor Tech';
					break;
				case '14' :
					$homepage = 'Elementor Travel';
					break;
				case '15' :
					$homepage = 'Elementor Lifestyle';
					break;
				case '16' :
					$homepage = 'Elementor Photography';
					break;
				case '17' :
					$homepage = 'Elementor Baby';
					break;
				case '18' :
					$homepage = 'Elementor Blogger';
					break;
				case '19' :
					$homepage = 'Elementor Work';
					break;
				case '20' :
					$homepage = 'Elementor Food';
					break;
				case '21' :
					$homepage = 'Elementor Gadget';
					break;
				case '22' :
					$homepage = 'Elementor Review';
					break;
				case '23' :
					$homepage = 'Elementor Fdeal';
					break;
				case '24' :
					$homepage = 'Elementor Freebie';
					break;
				case '25' :
					$homepage = 'Elementor Sport';
					break;
				case '26' :
					$homepage = 'Elementor RTL';
					break;
				case '27' :
					$homepage = 'Elementor Decor';
					break;
				case '28' :
					$homepage = 'Elementor Beauty';
					break;
				case '29' :
					$homepage = 'Elementor Medical';
					break;
				case '30' :
					$homepage = 'Elementor Yoga';
					break;
				case '31' :
					$homepage = 'Elementor Marketing';
					break;
				case '32' :
					$homepage = 'Elementor App';
					break;
				case '33' :
					$homepage = 'Elementor Game';
					break;
				case '34' :
					$homepage = 'Home Tutorial';
					break;
				case '35' :
					$homepage = 'Home Howtos';
					break;
				case '36' :
					$homepage = 'Home Podcast';
					break;
				case '37' :
					$homepage = 'Home Software';
					break;
				case '38' :
					$homepage = 'Elementor Outfit';
					break;
				case '39' :
					$homepage = 'Elementor Military';
					break;
				case '40' :
					$homepage = 'Elementor Crypto';
					break;
				case '41' :
					$homepage = 'Home Wedding';
					break;
				case '42' :
					$homepage = 'Home Architecture';
					break;
				case '43' :
					$homepage = 'Home Mom';
					break;
				case '44' :
					$homepage = 'Home News';
					break;
				case '45' :
					$homepage = 'Home Wellness';
					break;
				case '46' :
					$homepage = 'Home Today';
					break;
				case '47' :
					$homepage = 'Home Tasty';
					break;
			}
		} else {
			switch ( $directory ) {
				case '11' :
					$homepage = 'Home Recipe';
					break;
				case '12' :
					$homepage = 'Home Fashion';
					break;
				case '13' :
					$homepage = 'Home Tech';
					break;
				case '14' :
					$homepage = 'Home Travel';
					break;
				case '15' :
					$homepage = 'Home Lifestyle';
					break;
				case '16' :
					$homepage = 'Home Photography';
					break;
				case '17' :
					$homepage = 'Home Baby';
					break;
				case '18' :
					$homepage = 'Home Blogger';
					break;
				case '19' :
					$homepage = 'Home Work';
					break;
				case '20' :
					$homepage = 'Home Food';
					break;
				case '21' :
					$homepage = 'Home Gadget';
					break;
				case '22' :
					$homepage = 'Home Review';
					break;
				case '23' :
					$homepage = 'Home Fdeal';
					break;
				case '24' :
					$homepage = 'Home Freebie';
					break;
				case '25' :
					$homepage = 'Home Sport';
					break;
				case '26' :
					$homepage = 'Home RTL';
					break;
				case '27' :
					$homepage = 'Home Decor';
					break;
				case '28' :
					$homepage = 'Home Beauty';
					break;
				case '29' :
					$homepage = 'Home Medical';
					break;
				case '30' :
					$homepage = 'Home Yoga';
					break;
				case '31' :
					$homepage = 'Home Marketing';
					break;
				case '32' :
					$homepage = 'Home App';
					break;
				case '33' :
					$homepage = 'Home Game';
					break;
				case '34' :
					$homepage = 'Home Tutorial';
					break;
				case '35' :
					$homepage = 'Home Howtos';
					break;
				case '36' :
					$homepage = 'Home Podcast';
					break;
				case '37' :
					$homepage = 'Home Software';
					break;
				case '38' :
					$homepage = 'Elementor Outfit';
					break;
				case '39' :
					$homepage = 'Elementor Military';
					break;
				case '40' :
					$homepage = 'Elementor Crypto';
					break;
				case '41' :
					$homepage = 'Home Wedding';
					break;
				case '42' :
					$homepage = 'Home Architecture';
					break;
				case '43' :
					$homepage = 'Home Mom';
					break;
				case '44' :
					$homepage = 'Home News';
					break;
				case '45' :
					$homepage = 'Home Wellness';
					break;
				case '46' :
					$homepage = 'Home Today';
					break;
				case '47' :
					$homepage = 'Home Tasty';
					break;
			}
		}

		if ( ! empty( $homepage ) ) {
			$page = get_page_by_title( $homepage );
			if ( ! empty( $page->ID ) ) {
				update_option( 'page_on_front', $page->ID );
				update_option( 'show_on_front', 'page' );
				$blog = get_page_by_title( 'Blog' );
				if ( ! empty( $blog->ID ) ) {
					update_option( 'page_for_posts', $blog->ID );
				}
			} else {
				update_option( 'page_on_front', 0 );
				update_option( 'show_on_front', 'posts' );
			}
		}

		/** delete Hello word */
		// wp_delete_post( 1, true );

		/** setup WC */
		if ( class_exists( 'WC_Install' ) ) {
			WC_Install::create_pages();
		}

		/** setup menu */
		$main_menu   = get_term_by( 'name', 'main', 'nav_menu' );
		$footer_menu = get_term_by( 'name', 'footer', 'nav_menu' );
		$top_menu    = get_term_by( 'name', 'top', 'nav_menu' );

		$menu_locations = [];
		if ( isset( $main_menu->term_id ) ) {
			$menu_locations['pixwell_menu_main']      = $main_menu->term_id;
			$menu_locations['pixwell_menu_offcanvas'] = $main_menu->term_id;
		}
		if ( isset( $footer_menu->term_id ) ) {
			$menu_locations['pixwell_menu_footer'] = $footer_menu->term_id;
		}
		if ( isset( $top_menu->term_id ) ) {
			$menu_locations['pixwell_menu_top'] = $top_menu->term_id;
		}

		set_theme_mod( 'nav_menu_locations', $menu_locations );
	}
}

/** remove duplicated menu */
if ( ! function_exists( 'pixwell_importer_duplicate_menus' ) ) {
	function pixwell_importer_duplicate_menus() {

		$deleted_menus = [ 'main', 'top', 'footer', 'footer-col-1', 'footer-col-2', 'footer-col-3' ];
		foreach ( $deleted_menus as $menu ) {
			wp_delete_nav_menu( $menu );
		}

		return false;
	}
}

/** init widgets */
if ( ! function_exists( 'pixwell_importer_init_widgets' ) ) {
	function pixwell_importer_init_widgets() {

		//empty all sidebars
		$sidebars_widgets['pixwell_sidebar_default']       = [];
		$sidebars_widgets['pixwell_sidebar_offcanvas']     = [];
		$sidebars_widgets['pixwell_sidebar_topsite']       = [];
		$sidebars_widgets['pixwell_sidebar_single_top']    = [];
		$sidebars_widgets['pixwell_sidebar_single_bottom'] = [];
		$sidebars_widgets['pixwell_sidebar_fw_footer']     = [];
		$sidebars_widgets['pixwell_sidebar_footer_1']      = [];
		$sidebars_widgets['pixwell_sidebar_footer_2']      = [];
		$sidebars_widgets['pixwell_sidebar_footer_3']      = [];

		/** add sidebars */
		$theme_options                          = get_option( 'pixwell_theme_options' );
		$theme_options['pixwell_multi_sidebar'] = [ 'sb1', 'sb2', 'infinite', 'single' ];

		update_option( 'sidebars_widgets', $sidebars_widgets );
		update_option( 'pixwell_theme_options', $theme_options );

		/** register sidebar to import */
		register_sidebar( [
			'name'          => 'sb1',
			'id'            => 'pixwell_sidebar_multi_sb1',
			'before_widget' => '<div id="%1$s" class="widget widget-sidebar %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		] );

		register_sidebar( [
			'name'          => 'sb2',
			'id'            => 'pixwell_sidebar_multi_sb2',
			'before_widget' => '<div id="%1$s" class="widget widget-sidebar %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		] );

		register_sidebar( [
			'name'          => 'infinite',
			'id'            => 'pixwell_sidebar_multi_infinite',
			'before_widget' => '<div id="%1$s" class="widget widget-sidebar %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		] );

		register_sidebar( [
			'name'          => 'single',
			'id'            => 'pixwell_sidebar_multi_single',
			'before_widget' => '<div id="%1$s" class="widget widget-sidebar %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		] );

		register_sidebar( [
			'name'          => 'contact',
			'id'            => 'pixwell_sidebar_multi_contact',
			'before_widget' => '<div id="%1$s" class="widget widget-sidebar %2$s">',
			'after_widget'  => '</div>',
			'before_title'  => '<h3 class="widget-title">',
			'after_title'   => '</h3>',
		] );

		return false;
	}
}

/** setup category */
if ( ! function_exists( 'pixwell_importer_setup_category' ) ) {
	function pixwell_importer_setup_category( $directory, $path ) {

		$category_file = $path . 'categories.txt';
		$data          = [];

		if ( ! file_exists( $category_file ) ) {
			return false;
		}

		WP_Filesystem();
		global $wp_filesystem;
		$content  = $wp_filesystem->get_contents( $category_file );
		$settings = json_decode( $content, true );

		if ( ! is_array( $settings ) ) {
			return false;
		}

		$settings   = array_values( $settings );
		$categories = get_categories( [
			'hide_empty' => true,
			'info'       => 'post',
		] );
		$index      = 0;
		foreach ( $categories as $category ) {
			$id = $category->term_id;
			if ( isset( $settings[ $index ] ) ) {
				$data[ $id ] = $settings[ $index ];
			}
			$index ++;
		}

		update_option( 'pixwell_meta_categories', $data );

		return false;
	}
}

/** remove css cache */
if ( ! function_exists( 'pixwell_importer_remove_cache' ) ) {
	function pixwell_importer_remove_cache() {

		delete_option( 'pixwell_style_cache' );
		if ( function_exists( 'pixwell_write_dynamic_css' ) ) {
			pixwell_write_dynamic_css();
		}

		return false;
	}
}

if ( ! function_exists( 'pixwell_importer_header' ) ) {
	function pixwell_importer_header() {

		?>
		<div class="importer-header">
			<h2 class="importer-headline">
				<i class="dashicons dashicons-download"></i><?php esc_html_e( 'Ruby Importer - Install Demos' ); ?></h2>
			<div class="importer-desc">
				<p>Importing the theme demo allows you to quickly edit everything instead of creating content from
					scratch. Please <strong>DO NOT navigate away</strong> from this page while the importer is
					processing. This may take up to 5 ~ 7 minutes, depending on the server speed.</p>
				<p>We do not have the right to include some images of demos in the content due to copyright issues, so images
					will look different from the demo. The structures of demos will still be left intact so you can use your
					own images in their places if you desire.</p>
			</div>
			<div class="importer-tips">
				<p><strong>Import Tips:</strong></p>
				<p>- Refresh this page and re-import if the process cannot complete after 5 minutes.</p>
				<p>- You can choose to import Only Pages, Widgets, and Theme Options if your site already has data.</p>
				<p>-<strong>Don't need</strong> to install or activate Recommended & Optional plugins if you don't want
					to use them.
				</p>
				<p>- Install and activate the Woocommerce plugin before importing if you would like to set up a shop (Fashion
					Concept).</p>
				<p>- You can <strong>disable or delete</strong> the IMPORTER plugin after completion.</p>
				<p>- Online Documentation:
					<a href="http://help.themeruby.com/pixwell" target="_blank">HERE</a>
				</p>
			</div>
		</div>
		<?php
	}
}